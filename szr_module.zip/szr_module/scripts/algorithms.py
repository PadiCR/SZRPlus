﻿from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import StratifiedKFold
from sklearn.svm import SVC
import pandas as pd
import numpy as np
import math
#from pygam import LinearGAM,LogisticGAM
import pickle
import os
from collections import OrderedDict
#from pygam import terms
import csv
import matplotlib.pyplot as plt
import json


class Algorithms():

    def LR_simple(parameters):
        sc = StandardScaler()
        nomi=parameters['nomi']
        train=parameters['train']
        test=parameters['testy']
        X_train = sc.fit_transform(train[nomi])
        logistic_regression = LogisticRegression()
        logistic_regression.fit(X_train,train['y'])
        prob_fit=logistic_regression.predict_proba(X_train)[::,1]
        if parameters['testN']>0:
            X_test = sc.transform(test[nomi])
            predictions = logistic_regression.predict(X_test)
            #CI = logistic_regression.prediction_intervals(X_test, width=.95)
            prob_predic=logistic_regression.predict_proba(X_test)[::,1]
            test['SI']=prob_predic
        train['SI']=prob_fit
        return(train,test)
        
    def DT_simple(parameters):
        sc = StandardScaler()
        nomi=parameters['nomi']
        train=parameters['train']
        test=parameters['testy']
        X_train = sc.fit_transform(train[nomi])
        classifier = DecisionTreeClassifier(criterion = 'entropy', random_state = 0)
        classifier.fit(X_train,train['y'])
        prob_fit=classifier.predict_proba(X_train)[::,1]
        if parameters['testN']>0:
            X_test = sc.transform(test[nomi])
            predictions = classifier.predict(X_test)
            #CI = classifier.prediction_intervals(X_test, width=.95)
            prob_predic=classifier.predict_proba(X_test)[::,1]
            test['SI']=prob_predic
        train['SI']=prob_fit
        return(train,test)
    
    def RF_simple(parameters):
        sc = StandardScaler()
        nomi=parameters['nomi']
        train=parameters['train']
        test=parameters['testy']
        X_train = sc.fit_transform(train[nomi])
        classifier = RandomForestClassifier(n_estimators = 10, criterion = 'entropy', random_state = 0)
        classifier.fit(X_train,train['y'])
        prob_fit=classifier.predict_proba(X_train)[::,1]
        if parameters['testN']>0:
            X_test = sc.transform(test[nomi])
            predictions = classifier.predict(X_test)
            #CI = classifier.prediction_intervals(X_test, width=.95)
            prob_predic=classifier.predict_proba(X_test)[::,1]
            test['SI']=prob_predic
        train['SI']=prob_fit
        return(train,test)
    
    def SVC_simple(parameters):
        sc = StandardScaler()
        nomi=parameters['nomi']
        train=parameters['train']
        test=parameters['testy']
        X_train = sc.fit_transform(train[nomi])
        classifier = SVC(kernel = 'linear', random_state = 0,probability=True)
        classifier.fit(X_train,train['y'])
        prob_fit=classifier.predict_proba(X_train)[::,1]
        if parameters['testN']>0:
            X_test = sc.transform(test[nomi])
            predictions = classifier.predict(X_test)
            #CI = classifier.prediction_intervals(X_test, width=.95)
            prob_predic=classifier.predict_proba(X_test)[::,1]
            test['SI']=prob_predic
        train['SI']=prob_fit
        return(train,test)
    
    def fr_simple(parameters):
        df=parameters['train']
        test=parameters['testy']
        nomi=parameters['nomi']
        Npx1=None
        Npx2=None
        Npx3=None
        Npx4=None
        file = open(parameters['fold']+'/r_coeffs.txt','w')#################save W+, W- and Wf
        file.write('covariate,class,Npx1,Npx2,Npx3,Npx4,Wf\n')
        #print('covariates:',nomi)
        for ii in nomi:
            classi=df[ii].unique()
            for i in classi:
                dd=pd.DataFrame()
                dd = df.apply(lambda x : True if x['y'] == 1 and x[ii] == i else False, axis = 1)
                Npx1 = len(dd[dd == True].index)
                dd=pd.DataFrame()
                dd = df.apply(lambda x : True if x[ii] == i else False, axis = 1)
                Npx2 = len(dd[dd == True].index)
                dd=pd.DataFrame()
                dd = df.apply(lambda x : True if x['y'] == 1 else False, axis = 1)
                Npx3 = len(dd[dd == True].index)
                dd=pd.DataFrame()
                #dd = df.apply(lambda x : True if x['y'] == 0 and x['y'] == 1 else False, axis = 1)
                Npx4 = df.shape[0]#len(dd[dd == True].index)
                #print(Npx1,Npx2,Npx3,Npx4)
                if Npx1==0 or Npx3==0:
                    Wf=0.
                    #print(ii,i)
                else:
                    Wf=(np.divide((np.divide(Npx1,Npx2)),(np.divide(Npx3,Npx4))))
                #Wf=Wplus-Wminus
                var=[ii,i,Npx1,Npx2,Npx3,Npx4,Wf]
                file.write(','.join(str(e) for e in var)+'\n')#################save W+, W- and Wf
                df[ii][df[ii]==i]=float(Wf)
                test[ii][test[ii]==i]=float(Wf)
            #df.to_csv(self.f+'/file'+ii+'.csv')
        file.close()
        df['SI']=df[nomi].sum(axis=1)
        test['SI']=test[nomi].sum(axis=1)
        return(df,test)
    
    def woe_simple(parameters):
        df=parameters['train']
        test=parameters['testy']
        nomi=parameters['nomi']
        Npx1=None
        Npx2=None
        Npx3=None
        Npx4=None
        file = open(parameters['fold']+'/r_coeffs.txt','w')#################save W+, W- and Wf
        file.write('covariate,class,Npx1,Npx2,Npx3,Npx4,W+,W-,Wf\n')
        for ii in nomi:
            classi=df[ii].unique()
            for i in classi:
                dd=pd.DataFrame()
                dd = df.apply(lambda x : True if x['y'] == 1 and x[ii] == i else False, axis = 1)
                Npx1 = len(dd[dd == True].index)
                dd=pd.DataFrame()
                dd = df.apply(lambda x : True if x['y'] == 1 and x[ii] != i else False, axis = 1)
                Npx2 = len(dd[dd == True].index)
                dd=pd.DataFrame()
                dd = df.apply(lambda x : True if x['y'] == 0 and x[ii] == i else False, axis = 1)
                Npx3 = len(dd[dd == True].index)
                dd=pd.DataFrame()
                dd = df.apply(lambda x : True if x['y'] == 0 and x[ii] != i else False, axis = 1)
                Npx4 = len(dd[dd == True].index)
                if Npx1==0 or Npx3==0:
                    Wplus=0.
                else:
                    Wplus=math.log((Npx1/(Npx1+Npx2))/(Npx3/(Npx3+Npx4)))
                if Npx2==0 or Npx4==0:
                    Wminus=0.
                else:
                    Wminus=math.log((Npx2/(Npx1+Npx2))/(Npx4/(Npx3+Npx4)))
                Wf=Wplus-Wminus
                var=[ii,i,Npx1,Npx2,Npx3,Npx4,Wplus,Wminus,Wf]
                file.write(','.join(str(e) for e in var)+'\n')#################save W+, W- and Wf
                df[ii][df[ii]==i]=float(Wf)
                test[ii][test[ii]==i]=float(Wf)
            #df.to_csv(self.f+'/file'+ii+'.csv')
        file.close()
        df['SI']=df[nomi].sum(axis=1)
        test['SI']=test[nomi].sum(axis=1)
        return(df,test)
    
    # def GAM(parameters):
    #     nomi=parameters['nomi']
    #     X = parameters['df'][nomi].to_numpy()
    #     y = parameters['df'].PresAbs.to_numpy()
    #     lams = np.empty(len(nomi))
    #     lams.fill(0.5)
    #     gam = LogisticGAM(parameters['splines'], dtype=parameters['dtypes'])
    #     gam.gridsearch(X, y, lam=lams, progress=False)   

    #     # save
    #     filename = folder_models+'/cv_fold_'+hazard+'_'+str(n_fold)+'.pkl'
    #     with open(filename, 'wb') as filez:
    #         pickle.dump(gam, filez)
    #     return gam
    
    def GAM_simple(parameters):
        sc = StandardScaler()
        nomi=parameters['nomi']
        train=parameters['train']
        test=parameters['testy']
        #X_train=Algorithms.scaler(train,parameters['linear']+parameters['continuous'])
        X_train_sc = sc.fit_transform(train[parameters['linear']+parameters['continuous']])
        X_train = np.hstack((X_train_sc, train[parameters['categorical']]))
        lams = np.empty(len(nomi))
        lams.fill(0.5)        

        if parameters['family']=='binomial':
            gam = LogisticGAM(parameters['splines'], dtype=parameters['dtypes'])
            gam.gridsearch(X_train, train['y'], lam=lams)
            GAM_utils.GAM_plot(gam,parameters['train'],nomi,parameters['fold'],'',X_train)
            GAM_utils.GAM_save(gam,parameters['fold'])
            prob_fit=gam.predict_proba(X_train)#[::,1]
            train['SI']=prob_fit
            if parameters['testN']>0:
                X_test_sc = sc.transform(test[parameters['linear']+parameters['continuous']])
                X_test = np.hstack((X_test_sc, test[parameters['categorical']]))
                prob_predic=gam.predict_proba(X_test)#[::,1]
                test['SI']=prob_predic
                train['SI']=prob_fit
        else:
            gam = LinearGAM(parameters['splines'], dtype=parameters['dtypes'])
            gam.gridsearch(X_train, train['y'],lam=lams)
            GAM_utils.GAM_plot(gam,parameters['train'],nomi,parameters['fold'],'',X_train)
            GAM_utils.GAM_save(gam,parameters['fold'])
            prob_fit=gam.predict(X_train)#[::,1]
            #CI = gam.prediction_intervals(X_train, width=.95)
            train['SI']=prob_fit#np.exp(prob_fit)
            if parameters['testN']>0:
                X_test_sc = sc.transform(test[parameters['linear']+parameters['continuous']])
                X_test = np.hstack((X_test_sc, test[parameters['categorical']]))
                prob_predic=gam.predict(X_test)#[::,1]
                #CI = gam.prediction_intervals(X_test, width=.95)
                test['SI']=prob_predic#np.exp(prob_predic)
                train['SI']=prob_fit#np.exp(prob_fit)
        return(train,test,gam)
    
    def GAM_transfer(parameters):
        sc = StandardScaler()
        nomi=parameters['nomi']
        trans=parameters['trans']
        #X_trans = sc.fit_transform(trans[nomi])
        X_train_sc = sc.fit_transform(trans[parameters['linear']+parameters['continuous']])
        X_trans = np.hstack((X_train_sc, trans[parameters['categorical']]))
        if parameters['family']=='binomial':
            prob_fit=parameters['gam'].predict_proba(X_trans)#[::,1]
            trans['SI']=prob_fit
        else:
            prob_fit=parameters['gam'].predict(X_trans)#[::,1]
            #CI = parameters['gam'].prediction_intervals(X_trans, width=.95)
            trans['SI']=prob_fit#np.exp(prob_fit)
        return(trans)

    
    ####################################
    
    def LR_cv(classifier,X,y,train,test,fold=None,df=None,nomi=None):
        classifier.fit(X[train], y[train])
        prob_predic=classifier.predict_proba(X[test])[::,1]
        regression_coeff=classifier.coef_
        regression_intercept=classifier.intercept_
        coeff=np.hstack((regression_intercept,regression_coeff[0]))
        print(coeff,'regression coeff')
        #prob_fit=classifier.predict_proba(X[train])[::,1]
        return prob_predic,coeff
    
    def DT_cv(classifier,X,y,train,test,fold=None,df=None,nomi=None):
        classifier.fit(X[train], y[train])
        prob_predic=classifier.predict_proba(X[test])[::,1]
        # regression_coeff=classifier.coef_
        # regression_intercept=classifier.intercept_
        # coeff=np.hstack((regression_intercept,regression_coeff[0]))
        # print(coeff,'regression coeff')
        return prob_predic,None
    
    def RF_cv(classifier,X,y,train,test,fold=None,df=None,nomi=None):
        classifier.fit(X[train], y[train])
        prob_predic=classifier.predict_proba(X[test])[::,1]
        # regression_coeff=classifier.coef_
        # regression_intercept=classifier.intercept_
        # coeff=np.hstack((regression_intercept,regression_coeff[0]))
        # print(coeff,'regression coeff')
        return prob_predic,None
    
    def SVC_cv(classifier,X,y,train,test,fold=None,df=None,nomi=None):
        classifier.fit(X[train], y[train])
        prob_predic=classifier.predict_proba(X[test])[::,1]
        regression_coeff=classifier.coef_
        regression_intercept=classifier.intercept_
        coeff=np.hstack((regression_intercept,regression_coeff[0]))
        print(coeff,'regression coeff')
        return prob_predic,coeff
    
    def fr_cv(classifier,X,y,train,test,fold=None,df=None,nomi=None):
        dff=df.loc[train,:]
        test=df.loc[test,:]
        Npx1=None
        Npx2=None
        Npx3=None
        Npx4=None
        file = open(fold+'/r_coeff.txt','w')#################save W+, W- and Wf
        file.write('covariate,class,Npx1,Npx2,Npx3,Npx4,Wf\n')
        for ii in nomi:
            classi=dff[ii].unique()
            for i in classi:
                dd=pd.DataFrame()
                dd = dff.apply(lambda x : True if x['y'] == 1 and x[ii] == i else False, axis = 1)
                Npx1 = len(dd[dd == True].index)
                dd=pd.DataFrame()
                dd = dff.apply(lambda x : True if x[ii] == i else False, axis = 1)
                Npx2 = len(dd[dd == True].index)
                dd=pd.DataFrame()
                dd = dff.apply(lambda x : True if x['y'] == 1 else False, axis = 1)
                Npx3 = len(dd[dd == True].index)
                dd=pd.DataFrame()
                Npx4 = dff.shape[0]#len(dd[dd == True].index)
                if Npx1==0 or Npx3==0:
                    Wf=0.
                else:
                    Wf=(np.divide((np.divide(Npx1,Npx2)),(np.divide(Npx3,Npx4))))
                var=[ii,i,Npx1,Npx2,Npx3,Npx4,Wf]
                file.write(','.join(str(e) for e in var)+'\n')#################save W+, W- and Wf
                dff[ii][dff[ii]==i]=float(Wf)
                test[ii][test[ii]==i]=float(Wf)
        file.close()
        dff['SI']=dff[nomi].sum(axis=1)
        test['SI']=test[nomi].sum(axis=1)
        return(test['SI'],None)
    
    def woe_cv(classifier,X,y,train,test,fold=None,df=None,nomi=None):
        dff=df.loc[train,:]
        test=df.loc[test,:]
        Npx1=None
        Npx2=None
        Npx3=None
        Npx4=None
        file = open(fold+'/r_coeff.txt','w')#################save W+, W- and Wf
        file.write('covariate,class,Npx1,Npx2,Npx3,Npx4,W+,W-,Wf\n')
        for ii in nomi:
            classi=dff[ii].unique()
            for i in classi:
                dd=pd.DataFrame()
                dd = dff.apply(lambda x : True if x['y'] == 1 and x[ii] == i else False, axis = 1)
                Npx1 = len(dd[dd == True].index)
                dd=pd.DataFrame()
                dd = dff.apply(lambda x : True if x['y'] == 1 and x[ii] != i else False, axis = 1)
                Npx2 = len(dd[dd == True].index)
                dd=pd.DataFrame()
                dd = dff.apply(lambda x : True if x['y'] == 0 and x[ii] == i else False, axis = 1)
                Npx3 = len(dd[dd == True].index)
                dd=pd.DataFrame()
                dd = dff.apply(lambda x : True if x['y'] == 0 and x[ii] != i else False, axis = 1)
                Npx4 = len(dd[dd == True].index)
                if Npx1==0 or Npx3==0:
                    Wplus=0.
                else:
                    Wplus=math.log((Npx1/(Npx1+Npx2))/(Npx3/(Npx3+Npx4)))
                if Npx2==0 or Npx4==0:
                    Wminus=0.
                else:
                    Wminus=math.log((Npx2/(Npx1+Npx2))/(Npx4/(Npx3+Npx4)))
                Wf=Wplus-Wminus
                var=[ii,i,Npx1,Npx2,Npx3,Npx4,Wplus,Wminus,Wf]
                file.write(','.join(str(e) for e in var)+'\n')#################save W+, W- and Wf
                dff[ii][dff[ii]==i]=float(Wf)
                test[ii][test[ii]==i]=float(Wf)
            #df.to_csv(self.f+'/file'+ii+'.csv')
        file.close()
        dff['SI']=dff[nomi].sum(axis=1)
        test['SI']=test[nomi].sum(axis=1)
        return(test['SI'],None)
    
    def GAM_cv(classifier,X,y,train,test,splines=None,dtypes=None,nomi=None,df=None,fold=None,filename=None,scaler=None):
        lams = np.empty(len(nomi))
        lams.fill(0.5)
        gam = classifier(splines, dtype=dtypes)
        gam.gridsearch(X[train,], y[train], lam=lams,progress=False)
        GAM_utils.GAM_plot(gam,df.iloc[train,],nomi,fold,filename,X[train,])
        GAM_utils.GAM_save(gam,fold,filename)
        prob_predic=gam.predict_proba(X[test])#[::,1]
        CI={}#gam.prediction_intervals(X[test])
        GAM_utils.plot_predict(X[test],prob_predic,CI,fold,filename)

        return prob_predic,None,CI
    
    def scaler(df,nomes):
        df_scaled=df.copy()
        for nome in nomes:
            s=df[nome].std()
            u=df[nome].mean()
            df_scaled[nome]=(df[nome]-u)/s
        return df_scaled
            
    
class CV_utils():
    def cross_validation(parameters,algorithm,classifier):
        df=parameters['df']
        nomi=parameters['nomi']
        x=df[parameters['field1']]
        y=df['y']
        if algorithm==Algorithms.GAM_cv:
            X=Algorithms.scaler(x,parameters['linear']+parameters['continuous'])
            X[parameters['categorical']]=df[parameters['categorical']]
        else:
            sc = StandardScaler()#####scaler
            X = sc.fit_transform(x)
        #X=x
        #sc_fit = sc.fit(df[parameters['linear']+parameters['continuous']])
        
        train_ind={}
        test_ind={}
        prob={}
        CI={}
        cofl=[]
        df["SI"] = np.nan
        df["CI"] = np.nan
        if parameters['testN']>1:
            cv = StratifiedKFold(n_splits=parameters['testN'], shuffle=True, random_state=42)
            for i, (train, test) in enumerate(cv.split(X, y)):
                train_ind[i]=train
                test_ind[i]=test
                if algorithm==Algorithms.GAM_cv:
                    #X_train=X[train,]             
                    #X_train[parameters['linear']+parameters['continuous']]=sc.transform(X_train[parameters['linear']+parameters['continuous']])
                    #X_test=X[test,]             
                    #X_test[parameters['linear']+parameters['continuous']]=sc.transform(X_test[parameters['linear']+parameters['continuous']])
                    #print(X_train,X_test)
                    #prob[i],coeff=algorithm(classifier,X,y,train,test,splines=parameters['splines'],dtypes=parameters['dtypes'],nomi=nomi,df=df,fold=parameters['fold'],filename=str(i),scaler=sc)
                    lams = np.empty(len(nomi))
                    lams.fill(0.5)
                    gam = classifier(parameters['splines'], dtype=parameters['dtypes'])
                    gam.gridsearch(X.iloc[train,:].to_numpy(), y.iloc[train].to_numpy(), lam=lams,progress=False)
                    GAM_utils.GAM_plot(gam,df.iloc[train,:],nomi,parameters['fold'],str(i),X.iloc[train,:])
                    GAM_utils.GAM_save(gam,parameters['fold'],str(i))
                    prob[i]=gam.predict_proba(X.iloc[test,:].to_numpy())#[::,1]
                    CI[i]=[]#gam.prediction_intervals(X.iloc[test,:].to_numpy())
                    GAM_utils.plot_predict(X.iloc[test,:].to_numpy(),prob[i],CI,parameters['fold'], str(i))
                    coeff=None
                else:
                    print(parameters['fold'],'parms')
                    prob[i],coeff=algorithm(classifier,X,y,train,test,fold=parameters['fold'],df=df,nomi=nomi)
                df.loc[test,'SI']=prob[i]
                #df.loc[test,'CI']=[]#CI[i]
                cofl.append(coeff)
        elif parameters['testN']==1:
            train=np.arange(len(y))
            test=np.arange(len(y))
            if algorithm==Algorithms.GAM_cv:
                prob[0],coeff,CI[0]=algorithm(classifier,X,y,train,test,splines=parameters['splines'],dtypes=parameters['dtypes'],nomi=nomi,df=df,fold=parameters['fold'],filename='')
            else:
                prob[0],coeff=algorithm(classifier,X,y,train,test,fold=parameters['fold'],df=df,nomi=nomi)
            df.loc[test,'SI']=prob[0]
            #df.loc[test,'CI']=[]#CI[0]
            test_ind[0]=test
            cofl.append(coeff)
        if not os.path.exists(parameters['fold']):
            os.mkdir(parameters['fold'])
        if coeff is not None:
            with open(parameters['fold']+'/r_coeffs.csv', 'w') as f:
                write = csv.writer(f)
                ll=['intercept']
                lll=ll+nomi
                write.writerow(lll)
                write.writerows(cofl)
        return prob,test_ind
    
class GAM_utils():
    def GAM_formula(parameters):
        GAM_sel = parameters['nomi']
        spl = parameters['spline']
        splines = []
        dtypes = []
        vars_dict = OrderedDict({})

        for i in range(len(GAM_sel)):
            if GAM_sel[i] in parameters['continuous']:
                dtypes = dtypes + ['numerical']
                vars_dict[GAM_sel[i]]={'term':'s', 'n_splines':spl}
            elif GAM_sel[i] in parameters['categorical']:
                dtypes = dtypes + ['categorical']
                vars_dict[GAM_sel[i]]={'term':'f'}
            elif GAM_sel[i] in parameters['linear']:
                dtypes = dtypes + ['numerical']
                vars_dict[GAM_sel[i]]={'term':'l'}
        
        splines = terms.TermList()
        for i,v in enumerate(vars_dict .keys()):
            if vars_dict[v]['term'] == 's':
                term = terms.SplineTerm(i, n_splines=vars_dict[v].get('n_splines', 10))
            elif vars_dict[v]['term'] == 'l':
                term = terms.LinearTerm(i)
            elif vars_dict[v]['term'] == 'f':
                term = terms.FactorTerm(i)
            splines += term

        return splines,dtypes
    
    def GAM_plot(gam,df,nomi,fold,filename,scaled_df):
        GAM_sel=nomi
        #sc=StandardScaler()
        fig = plt.figure(figsize=(20, 25))

        maX=[]
        miN=[]
        for i, term in enumerate(gam.terms):
            if term.isintercept:
                continue
            pdep0, confi0 = gam.partial_dependence(term=i, X=gam.generate_X_grid(term=i), width=0.95)
            if isinstance(gam.terms[i], terms.FactorTerm):
                continue
            maX=maX+[np.max(confi0[:,1])]
            miN=miN+[np.min(confi0[:,0])]
        MAX=max(maX)+1
        MIN=min(miN)-1

        count=0
        countIns=0
        for i, term in enumerate(gam.terms):
            if term.isintercept:
                continue
            if isinstance(gam.terms[i], terms.FactorTerm):
                countIns+=1
                continue
            count+=1
        count=count+countIns

        x_tic=[]
        x_linear=np.array([])
        y_linear=np.array([])
            
        for i, term in enumerate(gam.terms):
            if term.isintercept:
                continue
            ##
            #XX = gam.generate_X_grid(term=i,n=len(df[GAM_sel[i]]))
            #pdep, confi = gam.partial_dependence(term=i, X=XX, width=0.95)
            ##
            XX=df[GAM_sel[i]].to_numpy()
            try:
                sorted_indices = np.argsort(scaled_df.iloc[:, i])
                X = scaled_df.iloc[sorted_indices].to_numpy()
            except:
                sorted_indices = np.argsort(scaled_df[:, i])
                X = scaled_df[sorted_indices]

            for ii in range(len(GAM_sel)):
                if ii != i: 
                    X[:, ii] = 0
            pdep, confi = gam.partial_dependence(term=i, X=X, width=0.95)
            ##

            YY=pdep
            if int(np.ceil(count/3.))<4:
                rows=4
            else:
                rows=int(np.ceil(count/3.))
            
            plt.subplot(rows, 3, i+1)

            if isinstance(gam.terms[i], terms.FactorTerm):
                plt.plot(np.sort(df[GAM_sel[i]]),pdep, 'o', c='blue')
                plt.xticks(np.sort(df[GAM_sel[i]].unique()), rotation=90)
                plt.xlabel(GAM_sel[i])
                plt.ylabel('Partial Effect')
                continue
            #elif isinstance(gam.terms[i], terms.LinearTerm):
            #    print(pdep)
            #    x_linear=np.append(x_linear,i)
            #    y_linear=np.append(y_linear,np.unique(pdep))
            #    x_tic=x_tic+[GAM_sel[i]]
            #    continue
            ##
            #plt.plot(XX[:, term.feature], pdep, c='blue')
            #plt.fill_between(XX[:, term.feature].ravel(), y1=confi[:,0], y2=confi[:,1], color='gray', alpha=0.2)
            ##
            ## plt.plot(XX[:, term.feature], confi, c='r', ls='--')
            plt.plot(np.sort(XX), pdep, c='blue')
            plt.fill_between(np.sort(XX), y1=confi[:,0], y2=confi[:,1], color='gray', alpha=0.2)

            plt.xlabel(GAM_sel[i])
            plt.ylabel('Partial Effect')
            plt.ylim(MIN,MAX)

        #if len(x_linear)>0:
        #    print(x_linear,y_linear)
        #    plt.plot(x_linear,y_linear, 'o', c='blue')
        #    plt.xticks(x_tic,rotation=90)
        #    #plt.xlabel(GAM_sel[i])
        #    plt.ylabel('Regression coefficient')

        plt.savefig(fold+'/Model_covariates'+filename+'.pdf', bbox_inches='tight')
        #plt.show()
    
        
    def GAM_save(gam,fold,filename=''):
        filename_pkl = fold+'/gam_coeff'+filename+'.pkl'
        #filename_txt = parameters['fold']+'/gam_coeff.txt'

        with open(filename_pkl, 'wb') as filez:
            pickle.dump(gam, filez)
        
        #with open(filename_pkl, 'rb') as file_pickle:
        #    loaded_data = pickle.load(file_pickle)

        #with open(filename_txt, 'wb') as file_txt:
        #    json.dump(loaded_data, file_txt, indent=2)
    
    def plot_predict(x,predict,CI,fold, filename=''):
        plt.plot(x,predict,'r--')
        #plt.plot(x,CI,color='b',ls='--')
        plt.xlabel('Prediction8')
        plt.ylabel('PDF')
        plt.savefig(fold+'/Predict'+filename+'.pdf')


# =============================================================================
# Raster-native algorithms  (v1.1.5 port)
# All methods operate on numpy arrays (no DataFrames / no vector I/O).
# They are called by sz_train_simple_r.py and sz_train_cv_r.py.
# =============================================================================

class Raster_Algorithms():
    """
    Each *_simple method:
        parameters keys: inv_path, cov_paths, cov_names, testN, folder
        returns dict:    si_pred, si_train, si_test, y_train, y_test,
                         pred_idx, georef
    Each *_cv method:
        parameters keys: inv_path, cov_paths, cov_names, kfolds, folder
        returns dict:    si_all, y_all, test_indices_list, pred_idx, georef
    """

    # ------------------------------------------------------------------ #
    #  Internal helpers                                                    #
    # ------------------------------------------------------------------ #

    def _load(parameters):
        """Load rasters and extract pixels. Returns (cov_stack, georef,
        X_all, y_all, X_pred, pred_idx, train_idx, base_stats)."""
        from szr_module.scripts.sz_raster_utils import (
            load_rasters, get_training_pixels, get_prediction_pixels,
            validate_alignment, read_raster_band
        )
        inv_path  = parameters['inv_path']
        cov_paths = parameters['cov_paths']
        validate_alignment([inv_path] + cov_paths)
        
        # Calculate base stats from raw inventory directly
        inv_raw = read_raster_band(inv_path)
        base_stats = {
            'Total Dataset Pixels': inv_raw.size,
            'Pixels with No Data': int(np.sum(np.isnan(inv_raw))),
            'Pixels with Data': int(np.sum(np.isfinite(inv_raw))),
            'Total Landslides': int(np.sum(inv_raw == 1)),
            'Total Non-Landslides': int(np.sum(inv_raw == 0))
        }
        
        cov_stack, georef = load_rasters(cov_paths)
        X_all, y_all, train_idx = get_training_pixels(inv_path, cov_stack, georef)
        X_pred, pred_idx  = get_prediction_pixels(cov_stack)
        return cov_stack, georef, X_all, y_all, X_pred, pred_idx, train_idx, base_stats

    def _split(X_all, y_all, testN):
        """Train/test split by percentage. Returns idx_tr, idx_te."""
        from sklearn.model_selection import train_test_split
        idx = np.arange(len(y_all))
        if testN > 0:
            n_test = max(1, int(np.ceil(len(y_all) * testN / 100)))
            idx_tr, idx_te = train_test_split(
                idx, test_size=n_test, random_state=42,
                stratify=y_all.astype(int))
        else:
            idx_tr = idx
            idx_te = idx
        return idx_tr, idx_te

    def _woe_predict(X_train, y_train, X_target, cov_names, folder,
                     save_weights=True):
        """WoE weights computed on train, applied to target. Returns si array."""
        si_target = np.zeros(len(X_target), dtype=np.float64)
        if save_weights:
            os.makedirs(folder, exist_ok=True)
            wfile = open(os.path.join(folder, 'woe_weights.csv'), 'w')
            wfile.write('covariate,class,Npx1,Npx2,Npx3,Npx4,W+,W-,Wf\n')
        for i in range(X_train.shape[1]):
            col_tr  = X_train[:, i]
            col_tgt = X_target[:, i]
            si_col  = np.zeros(len(X_target), dtype=np.float64)
            for cls in np.unique(col_tr):
                Npx1 = int(np.sum((col_tr == cls) & (y_train == 1)))
                Npx2 = int(np.sum((col_tr != cls) & (y_train == 1)))
                Npx3 = int(np.sum((col_tr == cls) & (y_train == 0)))
                Npx4 = int(np.sum((col_tr != cls) & (y_train == 0)))
                Wplus  = 0.0 if (Npx1 == 0 or Npx3 == 0) else \
                         math.log((Npx1/(Npx1+Npx2))/(Npx3/(Npx3+Npx4)))
                Wminus = 0.0 if (Npx2 == 0 or Npx4 == 0) else \
                         math.log((Npx2/(Npx1+Npx2))/(Npx4/(Npx3+Npx4)))
                Wf = Wplus - Wminus
                si_col[col_tgt == cls] = Wf
                if save_weights:
                    name = cov_names[i] if i < len(cov_names) else str(i)
                    wfile.write(f'{name},{cls},{Npx1},{Npx2},'
                                f'{Npx3},{Npx4},{Wplus:.6f},{Wminus:.6f},{Wf:.6f}\n')
            si_target += si_col
        if save_weights:
            wfile.close()
        return si_target

    def _fr_predict(X_train, y_train, X_target, cov_names, folder,
                    save_weights=True):
        """FR weights computed on train, applied to target. Returns si array."""
        si_target = np.zeros(len(X_target), dtype=np.float64)
        if save_weights:
            os.makedirs(folder, exist_ok=True)
            wfile = open(os.path.join(folder, 'fr_weights.csv'), 'w')
            wfile.write('covariate,class,Npx1,Npx2,Npx3,Npx4,Wf\n')
        Npx3_total = int(np.sum(y_train == 1))
        Npx4_total = len(y_train)
        for i in range(X_train.shape[1]):
            col_tr  = X_train[:, i]
            col_tgt = X_target[:, i]
            si_col  = np.zeros(len(X_target), dtype=np.float64)
            for cls in np.unique(col_tr):
                Npx1 = int(np.sum((col_tr == cls) & (y_train == 1)))
                Npx2 = int(np.sum(col_tr == cls))
                Wf = 0.0 if (Npx1 == 0 or Npx3_total == 0) else \
                     np.divide(np.divide(Npx1, Npx2),
                               np.divide(Npx3_total, Npx4_total))
                si_col[col_tgt == cls] = Wf
                if save_weights:
                    name = cov_names[i] if i < len(cov_names) else str(i)
                    wfile.write(f'{name},{cls},{Npx1},{Npx2},'
                                f'{Npx3_total},{Npx4_total},{Wf:.6f}\n')
            si_target += si_col
        if save_weights:
            wfile.close()
        return si_target

    # ------------------------------------------------------------------ #
    #  Simple (train/test%) methods                                        #
    # ------------------------------------------------------------------ #

    def woe_simple_r(parameters):
        _, georef, X_all, y_all, X_pred, pred_idx, train_idx, base_stats = \
            Raster_Algorithms._load(parameters)
        idx_tr, idx_te = Raster_Algorithms._split(
            X_all, y_all, parameters['testN'])
        X_train, y_train = X_all[idx_tr], y_all[idx_tr]
        X_test,  y_test  = X_all[idx_te], y_all[idx_te]
        cov_names = parameters.get('cov_names', [])
        folder    = parameters.get('folder', '')
        si_pred  = Raster_Algorithms._woe_predict(
            X_train, y_train, X_pred,    cov_names, folder, save_weights=True)
        si_train = Raster_Algorithms._woe_predict(
            X_train, y_train, X_train, cov_names, folder, save_weights=False)
        si_test  = Raster_Algorithms._woe_predict(
            X_train, y_train, X_test,  cov_names, folder, save_weights=False)
        return {'si_pred': si_pred, 'si_train': si_train, 'si_test': si_test,
                'y_train': y_train, 'y_test': y_test,
                'pred_idx': pred_idx, 'georef': georef,
                'train_idx': train_idx, 'idx_tr': idx_tr, 'idx_te': idx_te, 'base_stats': base_stats}

    def fr_simple_r(parameters):
        _, georef, X_all, y_all, X_pred, pred_idx, train_idx, base_stats = \
            Raster_Algorithms._load(parameters)
        idx_tr, idx_te = Raster_Algorithms._split(
            X_all, y_all, parameters['testN'])
        X_train, y_train = X_all[idx_tr], y_all[idx_tr]
        X_test,  y_test  = X_all[idx_te], y_all[idx_te]
        cov_names = parameters.get('cov_names', [])
        folder    = parameters.get('folder', '')
        si_pred  = Raster_Algorithms._fr_predict(
            X_train, y_train, X_pred,  cov_names, folder, save_weights=True)
        si_train = Raster_Algorithms._fr_predict(
            X_train, y_train, X_train, cov_names, folder, save_weights=False)
        si_test  = Raster_Algorithms._fr_predict(
            X_train, y_train, X_test,  cov_names, folder, save_weights=False)
        return {'si_pred': si_pred, 'si_train': si_train, 'si_test': si_test,
                'y_train': y_train, 'y_test': y_test,
                'pred_idx': pred_idx, 'georef': georef,
                'train_idx': train_idx, 'idx_tr': idx_tr, 'idx_te': idx_te, 'base_stats': base_stats}

    def _sklearn_simple_r(parameters, classifier):
        from sklearn.preprocessing import StandardScaler
        _, georef, X_all, y_all, X_pred, pred_idx, train_idx, base_stats = \
            Raster_Algorithms._load(parameters)
        idx_tr, idx_te = Raster_Algorithms._split(
            X_all, y_all, parameters['testN'])
        X_train, y_train = X_all[idx_tr], y_all[idx_tr]
        X_test,  y_test  = X_all[idx_te], y_all[idx_te]
        sc = StandardScaler()
        X_train_sc = sc.fit_transform(X_train)
        X_test_sc  = sc.transform(X_test)
        X_pred_sc  = sc.transform(X_pred)
        classifier.fit(X_train_sc, y_train)
        si_train = classifier.predict_proba(X_train_sc)[:, 1]
        si_test  = classifier.predict_proba(X_test_sc)[:, 1]
        si_pred  = classifier.predict_proba(X_pred_sc)[:, 1]
        return {'si_pred': si_pred, 'si_train': si_train, 'si_test': si_test, 'y_train': y_train, 'y_test': y_test, 'pred_idx': pred_idx, 'georef': georef, 'train_idx': train_idx, 'idx_tr': idx_tr, 'idx_te': idx_te, 'base_stats': base_stats}

    def LR_simple_r(parameters):
        from sklearn.linear_model import LogisticRegression
        return Raster_Algorithms._sklearn_simple_r(
            parameters, LogisticRegression())

    def RF_simple_r(parameters):
        from sklearn.ensemble import RandomForestClassifier
        return Raster_Algorithms._sklearn_simple_r(
            parameters,
            RandomForestClassifier(n_estimators=10, criterion='entropy',
                                   random_state=0))

    def SVC_simple_r(parameters):
        from sklearn.svm import SVC
        return Raster_Algorithms._sklearn_simple_r(
            parameters,
            SVC(kernel='linear', random_state=0, probability=True))

    def DT_simple_r(parameters):
        from sklearn.tree import DecisionTreeClassifier
        return Raster_Algorithms._sklearn_simple_r(
            parameters,
            DecisionTreeClassifier(criterion='entropy', random_state=0))

    # ------------------------------------------------------------------ #
    #  k-fold CV methods                                                   #
    # ------------------------------------------------------------------ #

    def _woe_kfold(parameters):
        from sklearn.model_selection import StratifiedKFold
        _, georef, X_all, y_all, X_pred, pred_idx, train_idx, base_stats = \
            Raster_Algorithms._load(parameters)
        kfolds    = max(2, int(parameters.get('kfolds', 5)))
        cov_names = parameters.get('cov_names', [])
        folder    = parameters.get('folder', '')
        cv = StratifiedKFold(n_splits=kfolds, shuffle=True, random_state=42)
        si_all = np.full(len(y_all), np.nan, dtype=np.float64)
        si_pred_acc = np.zeros(len(X_pred), dtype=np.float64)
        test_indices_list = []
        for fold_i, (tr_idx, te_idx) in enumerate(
                cv.split(X_all, y_all.astype(int))):
            X_tr, y_tr = X_all[tr_idx], y_all[tr_idx]
            X_te       = X_all[te_idx]
            si_te = Raster_Algorithms._woe_predict(
                X_tr, y_tr, X_te, cov_names,
                os.path.join(folder, f'fold_{fold_i}'), save_weights=True)
            si_all[te_idx] = si_te
            si_pred_acc += Raster_Algorithms._woe_predict(
                X_tr, y_tr, X_pred, cov_names, folder, save_weights=False)
            test_indices_list.append(te_idx)
        si_pred_avg = si_pred_acc / kfolds
        return {'si_all': si_all, 'y_all': y_all,
                'si_pred': si_pred_avg,
                'test_indices_list': test_indices_list,
                'pred_idx': pred_idx, 'georef': georef,
                'train_idx': train_idx, 'base_stats': base_stats}

    def woe_cv_r(parameters):
        return Raster_Algorithms._woe_kfold(parameters)

    def _fr_kfold(parameters):
        from sklearn.model_selection import StratifiedKFold
        _, georef, X_all, y_all, X_pred, pred_idx, train_idx, base_stats = \
            Raster_Algorithms._load(parameters)
        kfolds    = max(2, int(parameters.get('kfolds', 5)))
        cov_names = parameters.get('cov_names', [])
        folder    = parameters.get('folder', '')
        cv = StratifiedKFold(n_splits=kfolds, shuffle=True, random_state=42)
        si_all = np.full(len(y_all), np.nan, dtype=np.float64)
        si_pred_acc = np.zeros(len(X_pred), dtype=np.float64)
        test_indices_list = []
        for fold_i, (tr_idx, te_idx) in enumerate(
                cv.split(X_all, y_all.astype(int))):
            X_tr, y_tr = X_all[tr_idx], y_all[tr_idx]
            X_te       = X_all[te_idx]
            si_te = Raster_Algorithms._fr_predict(
                X_tr, y_tr, X_te, cov_names,
                os.path.join(folder, f'fold_{fold_i}'), save_weights=True)
            si_all[te_idx] = si_te
            si_pred_acc += Raster_Algorithms._fr_predict(
                X_tr, y_tr, X_pred, cov_names, folder, save_weights=False)
            test_indices_list.append(te_idx)
        si_pred_avg = si_pred_acc / kfolds
        return {'si_all': si_all, 'y_all': y_all,
                'si_pred': si_pred_avg,
                'test_indices_list': test_indices_list,
                'pred_idx': pred_idx, 'georef': georef,
                'train_idx': train_idx, 'base_stats': base_stats}

    def fr_cv_r(parameters):
        return Raster_Algorithms._fr_kfold(parameters)

    def _sklearn_kfold(parameters, make_classifier):
        """Shared k-fold logic for sklearn methods."""
        from sklearn.preprocessing import StandardScaler
        from sklearn.model_selection import StratifiedKFold
        _, georef, X_all, y_all, X_pred, pred_idx, train_idx, base_stats = \
            Raster_Algorithms._load(parameters)
        kfolds = max(2, int(parameters.get('kfolds', 5)))
        folder = parameters.get('folder', '')
        cv = StratifiedKFold(n_splits=kfolds, shuffle=True, random_state=42)
        si_all = np.full(len(y_all), np.nan, dtype=np.float64)
        si_pred_acc = np.zeros(len(X_pred), dtype=np.float64)
        test_indices_list = []
        for tr_idx, te_idx in cv.split(X_all, y_all.astype(int)):
            sc = StandardScaler()
            X_tr_sc = sc.fit_transform(X_all[tr_idx])
            X_te_sc = sc.transform(X_all[te_idx])
            X_pr_sc = sc.transform(X_pred)
            clf = make_classifier()
            clf.fit(X_tr_sc, y_all[tr_idx])
            si_all[te_idx]   = clf.predict_proba(X_te_sc)[:, 1]
            si_pred_acc      += clf.predict_proba(X_pr_sc)[:, 1]
            test_indices_list.append(te_idx)
        si_pred_avg = si_pred_acc / kfolds
        return {'si_all': si_all, 'y_all': y_all,
                'si_pred': si_pred_avg,
                'test_indices_list': test_indices_list,
                'pred_idx': pred_idx, 'georef': georef,
                'train_idx': train_idx, 'base_stats': base_stats}

    def LR_cv_r(parameters):
        from sklearn.linear_model import LogisticRegression
        return Raster_Algorithms._sklearn_kfold(
            parameters, lambda: LogisticRegression())

    def RF_cv_r(parameters):
        from sklearn.ensemble import RandomForestClassifier
        return Raster_Algorithms._sklearn_kfold(
            parameters,
            lambda: RandomForestClassifier(n_estimators=10, criterion='entropy',
                                           random_state=0))

    def SVC_cv_r(parameters):
        from sklearn.svm import SVC
        return Raster_Algorithms._sklearn_kfold(
            parameters,
            lambda: SVC(kernel='linear', random_state=0, probability=True))

    def DT_cv_r(parameters):
        from sklearn.tree import DecisionTreeClassifier
        return Raster_Algorithms._sklearn_kfold(
            parameters,
            lambda: DecisionTreeClassifier(criterion='entropy', random_state=0))
